package com.example.pizza.adapters;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizza.MenuItemDetailedActivity;
import com.example.pizza.OrderDetailsActivity;
import com.example.pizza.R;
import com.example.pizza.database.model.Orders;
import com.example.pizza.database.relation.MenuItemDB;

import org.w3c.dom.Text;

import java.util.List;

public class OrderListAdapter extends RecyclerView.Adapter<OrderListAdapter.OrderViewHolder>{
    private List<Orders> ordersList;

    public OrderListAdapter(List<Orders> ordersList) {
        this.ordersList = ordersList;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.order_item, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Orders order = ordersList.get(position);
        holder.refNum.setText("Reference No: Ref"+order.getId());
        holder.totalItems.setText("Order Items: "+order.getTotalQuantity());
        holder.totalAmount.setText("Order Total: "+order.getTotalPrice());
    }

    @Override
    public int getItemCount() {
        return ordersList.size();
    }

    public class OrderViewHolder  extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView refNum,totalItems,totalAmount;
        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            refNum = itemView.findViewById(R.id.orderRef);
            totalItems = itemView.findViewById(R.id.orderItems);
            totalAmount = itemView.findViewById(R.id.orderTotal);
            itemView.setOnClickListener(this::onClick);

        }
        @Override
        public void onClick(View v) {
            Orders order = ordersList.get(getAdapterPosition());
            if (v.getContext() != null) {
                Intent intent = new Intent(v.getContext(), OrderDetailsActivity.class);
                intent.putExtra("order_uid", order.getId());
                intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                v.getContext().startActivity(intent);
            }

        }
    }
}
