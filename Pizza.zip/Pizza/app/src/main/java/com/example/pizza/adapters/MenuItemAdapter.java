package com.example.pizza.adapters;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizza.MenuItemDetailedActivity;
import com.example.pizza.R;
import com.example.pizza.database.relation.MenuItemDB;

import java.util.List;


public class MenuItemAdapter extends RecyclerView.Adapter<MenuItemAdapter.ViewHolder> {
    private List<MenuItemDB> dataList;
    private Context context;
    private View.OnClickListener onClickListener;

    public MenuItemAdapter(Context context) {
        this.context = context;
    }


    public MenuItemAdapter() {
    }

    public void setData(List data) {
        dataList = data;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.menu_list, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.getName().setText(dataList.get(position).getName());
        holder.getDesc().setText(dataList.get(position).getDescription());
        holder.getPrice().setText(dataList.get(position).getPrice() + " $");
        holder.getImage().setBackgroundResource(dataList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return dataList == null? 0:dataList.toArray().length;
    }



    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final TextView name;
        private final TextView desc;
        private final TextView price;
        private final ImageView image;

        public ViewHolder(View view) {
            super(view);
            name = (TextView) view.findViewById(R.id.menu_name);
            desc = (TextView) view.findViewById(R.id.menu_description);
            price = (TextView) view.findViewById(R.id.menu_price);
            image = (ImageView) view.findViewById(R.id.menu_image);
            view.setOnClickListener(this);
        }

        public TextView getName() {
            return name;
        }

        public TextView getDesc() {
            return desc;
        }

        public TextView getPrice() {
            return price;
        }

        public ImageView getImage() {
            return image;
        }

        @Override
        public void onClick(View v) {
            MenuItemDB menuItem = dataList.get(getAdapterPosition());
            if (context != null) {
                Intent intent = new Intent(context, MenuItemDetailedActivity.class);
                intent.putExtra("menu_id", menuItem.getId());
                intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }

        }
    }


}

