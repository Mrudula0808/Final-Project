package com.example.pizza;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizza.adapters.MenuItemAdapter;
import com.example.pizza.database.AppDatabase;
import com.example.pizza.database.DatabaseClient;
import com.example.pizza.database.dao.CartDao;
import com.example.pizza.database.dao.MenuDao;
import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.MenuItem;
import com.example.pizza.database.relation.MenuItemDB;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private AppDatabase db;
    private RecyclerView recyclerView;
    private List<MenuItemDB> menuItemDBS;
    private MenuItemAdapter adapter;
    private MenuDao menuDao;
    private CartDao cartDao;
    private TextView cartBadge;
    private List<CartItem> cartItemList;
    private SharedPreferences preferences;
    private void generateDummyData() {
        List<MenuItem> menuItems = new ArrayList<>();

        menuItems.add(new MenuItem("FarmHouse" , "Delightful combination of onion, capsicum, tomato & grilled mushroom", 10, R.drawable.pizza));
        menuItems.add(new MenuItem("Margherita" , "Classic delight with 100% real mozzarella cheese", 13, R.drawable.pizza));
        menuItems.add(new MenuItem("Peppy Paneer" , "Flavorful trio of juicy paneer, crisp capsicum with spicy red paprika", 8, R.drawable.pizza));
        menuItems.add(new MenuItem("Veggie Paradise" , "The awesome foursome! Golden corn, black olives, capsicum, red paprika", 9, R.drawable.pizza));
        menuItems.add(new MenuItem("Veg Extravaganza" , "Black olives, capsicum, onion, grilled mushroom, corn, tomato, jalapeno & extra cheese", 10, R.drawable.pizza));
        menuItems.add(new MenuItem("The Unthinkable Pizza" , "Loaded with Plant Based Protein topping along with Black Olives & Red Paprika enjoy this unique 100% Vegetarian pizza with a 100% Chicken like taste!", 10, R.drawable.pizza));
        menuItems.add(new MenuItem("Chicken Sausage" , "American classic! Spicy, herbed chicken sausage on pizza", 15, R.drawable.pizza));
        menuItems.add(new MenuItem("Cheese n Corn" , "A delectable combination of sweet & juicy golden corn", 13, R.drawable.pizza));
        menuItems.add(new MenuItem("Indo Fusion Chicken Pizza" , "Relish the fusion of 5 of your favorite chicken toppings - Peri Peri Chicken, Chicken Pepperoni, Chicken Tikka, Pepper Barbecue Chicken and Chicken Meatballs", 20, R.drawable.pizza));

        menuDao.insertListMenu(menuItems);
        this.recreate();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preferences = getSharedPreferences("User", MODE_PRIVATE);
        if (preferences.getInt("User_UID", 0) == 0) {
            finish();
        }
        adapter = new MenuItemAdapter(this);
        recyclerView = findViewById(R.id.menu_recyclerView);
        recyclerView.setAdapter(adapter);
        db = DatabaseClient.getInstance(getApplicationContext()).getAppDb();
        menuDao = db.menuDao();
        cartDao = db.cartDao();

        menuItemDBS = menuDao.getMenuDB();
        if (menuItemDBS.size() > 0) {
            invalidateOptionsMenu();
        } else {
            generateDummyData();
        }
        loadMenuItems();
    }

    private void updateCartBadge() {
        cartItemList = cartDao.getAllCartItem(preferences.getInt("User_UID", 0));
        if (cartBadge != null) {
            cartBadge.setText(String.valueOf(cartItemList.size()));
            invalidateOptionsMenu();
        }
    }

    private void loadMenuItems() {
        updateCartBadge();
        menuItemDBS = menuDao.getMenuDB();
        adapter.setData(menuItemDBS);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        final android.view.MenuItem menuItem = menu.findItem(R.id.cart);
        View actionView = menuItem.getActionView();
        cartBadge = actionView.findViewById(R.id.cart_badge);
        actionView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onOptionsItemSelected(menuItem);
            }
        });
        updateCartBadge();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cart:
                Intent cartInt = new Intent(this, CartListActivity.class);
                startActivity(cartInt);
                break;
            case R.id.orders:
                Intent intent = new Intent(this, OrdersListActivity.class);
                startActivity(intent);
                break;
            case R.id.log_out:
                SharedPreferences.Editor editor = preferences.edit();
                editor.remove("User_UID");
                editor.apply();
                Intent login = new Intent(this, LoginActivity.class);
                startActivity(login);
                finish();
                break;
            default:
                break;
        }
        return true;
    }


    @Override
    protected void onResume() {
        super.onResume();
        loadMenuItems();
    }
}