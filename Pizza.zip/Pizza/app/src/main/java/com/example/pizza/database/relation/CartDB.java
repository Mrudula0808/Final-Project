package com.example.pizza.database.relation;

import androidx.room.Relation;

import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.MenuItem;
import com.example.pizza.database.model.OrderItem;
import com.example.pizza.database.model.Orders;

import java.util.List;

public class CartDB extends CartItem {

    @Relation(parentColumn = "menuItem_id",
            entityColumn = "id",
            entity = MenuItem.class)
    private MenuItem menuItem;
}
