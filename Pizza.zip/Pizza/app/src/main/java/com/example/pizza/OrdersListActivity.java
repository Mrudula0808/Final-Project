package com.example.pizza;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import com.example.pizza.adapters.CartListAdapter;
import com.example.pizza.adapters.OrderListAdapter;
import com.example.pizza.database.AppDatabase;
import com.example.pizza.database.DatabaseClient;
import com.example.pizza.database.dao.CartDao;
import com.example.pizza.database.dao.OrderDao;
import com.example.pizza.database.model.Orders;

import java.util.List;

public class OrdersListActivity extends AppCompatActivity {
    private RecyclerView orderListView;
    private AppDatabase db;
    private OrderDao orderDao;
    private OrderListAdapter adapter;
    private SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders_list);
        preferences = getSharedPreferences("User", MODE_PRIVATE);
        if (preferences.getInt("User_UID", 0) == 0) {
            finish();
        }
        orderListView = findViewById(R.id.ordersList);
        db = DatabaseClient.getInstance(getApplicationContext()).getAppDb();
        orderDao = db.orderDao();
        loadMyOrders();
    }

    private void loadMyOrders() {
        List<Orders> orders = orderDao.getAllOrders(preferences.getInt("User_UID", 0));
        adapter = new OrderListAdapter(orders);
        orderListView.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Orders");
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}