package com.example.pizza.database.dao;

import static androidx.room.OnConflictStrategy.REPLACE;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.MenuItem;
import com.example.pizza.database.model.OrderItem;
import com.example.pizza.database.model.Orders;
import com.example.pizza.database.relation.OrdersDB;

import java.util.ArrayList;
import java.util.List;

@Dao
public abstract class OrderDao {
    @Query("SELECT * FROM orders where user_uid=:user")
    public abstract List<Orders> getAllOrders(int user);

    @Query("SELECT * FROM orders where id = :uid")
    public abstract OrdersDB getOrderDB(int uid);

    @Insert(onConflict = REPLACE)
    public abstract void insertOrder(OrderItem orders);

    @Insert
    public abstract void insertListOrder(List<OrderItem> ordersItemList);

    @Insert(onConflict = REPLACE)
    public abstract long insertOrder(Orders order);

    @Update
    public abstract void updateOrder(OrderItem orderItem);

    @Delete
    public abstract void deleteOrder(OrderItem orderItem);

    @Transaction
    public void orderCartLists(List<CartItem> cartList, int user_uid) {
        ArrayList<OrderItem> items = new ArrayList<>();
        int total = 0;
        Orders order = new Orders();
        for (CartItem item : cartList) {
            MenuItem menuItem = item.getMenuItem();
            OrderItem oderItem = new OrderItem();
            oderItem.setName(menuItem.getName());
            oderItem.setDescription(menuItem.getDescription());
            oderItem.setPrice(menuItem.getPrice());
            oderItem.setImage(menuItem.getImage());
            oderItem.setTotalQuantity(item.getTotalQuantity());
            oderItem.setTotalPrice(oderItem.getTotalQuantity() * oderItem.getPrice());
            total += oderItem.getTotalPrice();
            items.add(oderItem);
        }
        order.setTotalQuantity(items.size());
        order.setTotalPrice(total);
        order.setUser_uid(user_uid);
        long orderId = insertOrder(order);
        for (OrderItem item : items) {
            item.setOrderItem_id((int) orderId);
            insertOrder(item);
        }
        clearCart(user_uid);

    }

    @Query("delete from cart where user_uid=:user")
    protected abstract void clearCart(int user);
}
