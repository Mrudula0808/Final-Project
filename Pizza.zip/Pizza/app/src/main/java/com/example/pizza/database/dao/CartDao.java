package com.example.pizza.database.dao;

import static androidx.room.OnConflictStrategy.REPLACE;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.relation.CartDB;

import java.util.List;

@Dao
public interface CartDao {
    @Query("SELECT * FROM cart where user_uid=:user_uid")
    List<CartItem> getAllCartItem(int user_uid);

    @Query("SELECT * FROM cart where user_uid=:user")
    List<CartDB> getCartDB(int user);

    @Query("SELECT * FROM cart WHERE id IN (:ids)")
    List<CartItem> getAllByIds(int[] ids);

    @Query("SELECT * FROM cart WHERE menuItem_id = :menu_id")
    CartItem getCartByMenuId(int menu_id);

    @Insert(onConflict = REPLACE)
    void insertCart(CartItem cart);

    @Insert
    void insertListCart(List<CartItem> cartItemList);

    @Update
    void updateCart(CartItem product);

    @Delete
    void deleteCart(CartItem cart);
}
