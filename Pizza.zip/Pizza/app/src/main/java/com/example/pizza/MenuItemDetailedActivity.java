package com.example.pizza;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pizza.database.AppDatabase;
import com.example.pizza.database.DatabaseClient;
import com.example.pizza.database.dao.MenuDao;
import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class MenuItemDetailedActivity extends AppCompatActivity {
    private AppDatabase db;
    private MenuDao menuDao;
    private ImageView menuImage;
    private TextView name, price, description, totalAmount;
    private Spinner quantitySpinner;
    private MenuItem menuItem;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_item_details);
        preferences = getSharedPreferences("User", MODE_PRIVATE);
        if (preferences.getInt("User_UID", 0) == 0) {
            finish();
        }
        menuImage = findViewById(R.id.menu_Item_image);
        name = findViewById(R.id.item_name);
        price = findViewById(R.id.item_price);
        description = findViewById(R.id.item_description);
        totalAmount = findViewById(R.id.totalAmount);
        quantitySpinner = findViewById(R.id.card_quantity_selector);
        db = DatabaseClient.getInstance(getApplicationContext()).getAppDb();
        menuDao = db.menuDao();
        quantitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String rawQuantity = (String) quantitySpinner.getAdapter().getItem(i);
                int finalValue = Integer.valueOf(rawQuantity);
                menuItem.getCartItem().setTotalQuantity(finalValue);
                totalAmount.setText(menuItem.getPrice() * finalValue + "$");

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        Intent menuIntent = getIntent();
        if (menuIntent != null && menuIntent.getExtras() != null) {
            int menuId = menuIntent.getExtras().getInt("menu_id", -1);
            if (menuId != -1) {
                loadMenuDetails(menuId);
            }
        }
        findViewById(R.id.addCart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (menuItem != null && menuItem.getCartItem() != null) {
                    db.cartDao().insertCart(menuItem.getCartItem());
                    Toast.makeText(getApplicationContext(), "Item Added successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadMenuDetails(int menuId) {
        menuItem = menuDao.getMenuItemDB(menuId);
        CartItem cart = menuDao.getCart(menuItem.getId(),preferences.getInt("User_UID", 0));
        if (cart == null) {
            cart = new CartItem();
            cart.setMenuItem_id(menuItem.getId());
            cart.setTotalQuantity(1);
            cart.setUser_uid(preferences.getInt("User_UID", 0));
        }
        menuItem.setCartItem(cart);

        List<String> quantityList = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            quantityList.add(String.valueOf(i));
        }
        name.setText(menuItem.getName());
        price.setText("$: " + menuItem.getPrice());
        description.setText(menuItem.getDescription());
        menuImage.setImageResource(menuItem.getImage());
        ArrayAdapter quantityAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, quantityList);
        quantitySpinner.setAdapter(quantityAdapter);
        String cartQty = String.valueOf(cart.getTotalQuantity());
        int index = quantityList.indexOf(cartQty);
        if (index != -1) {
            quantitySpinner.setSelection(index);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Details");
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}