package com.example.pizza.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizza.R;
import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.OrderItem;

import java.util.ArrayList;
import java.util.List;

public class OrderItemsListAdapter extends RecyclerView.Adapter<OrderItemsListAdapter.CartViewHolder> {
    private List<OrderItem> orderItemList;

    public OrderItemsListAdapter(List<OrderItem> orderItemList) {
        this.orderItemList = orderItemList;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cart_list_item, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        OrderItem item = orderItemList.get(position);
        holder.itemName.setText(item.getName());
        holder.itemPrice.setText("Price: $" + item.getPrice());
        holder.total.setText("Total: $" + item.getTotalPrice());
        holder.imageView.setImageResource(item.getImage());
        ArrayAdapter adapter = new ArrayAdapter(holder.itemView.getContext(), android.R.layout.simple_list_item_1, new String[]{String.valueOf(item.getTotalQuantity())});
        holder.quantitySpin.setAdapter(adapter);

    }

    @Override
    public int getItemCount() {
        return orderItemList == null ? 0 : orderItemList.size();
    }


    public class CartViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemPrice, total;
        ImageView imageView;
        Spinner quantitySpin;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.cart_image);
            itemName = itemView.findViewById(R.id.cart_name);
            itemPrice = itemView.findViewById(R.id.unitPrice);
            total = itemView.findViewById(R.id.cart_price);
            quantitySpin = itemView.findViewById(R.id.spinner_quantity);
            itemView.findViewById(R.id.deletedCart).setVisibility(View.GONE);
        }
    }
}
