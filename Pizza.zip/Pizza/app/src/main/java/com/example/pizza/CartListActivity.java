package com.example.pizza;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pizza.adapters.CartListAdapter;
import com.example.pizza.database.AppDatabase;
import com.example.pizza.database.DatabaseClient;
import com.example.pizza.database.dao.CartDao;
import com.example.pizza.database.dao.MenuDao;
import com.example.pizza.database.model.CartItem;

import java.util.ArrayList;
import java.util.List;

public class CartListActivity extends AppCompatActivity implements CartListAdapter.OnQuantityChangeListener {
    private RecyclerView cartListView;
    private TextView totalItems,totalAmount;
    private AppDatabase db;
    private CartDao cartDao;
    private CartListAdapter adapter;
    private SharedPreferences preferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart_view);
        preferences = getSharedPreferences("User", MODE_PRIVATE);
        if (preferences.getInt("User_UID", 0) == 0) {
            finish();
        }
        cartListView = findViewById(R.id.cart_list_handler);
        totalItems = findViewById(R.id.totalCartSize);
        totalAmount = findViewById(R.id.totalCartAmount);
        db = DatabaseClient.getInstance(getApplicationContext()).getAppDb();
        cartDao = db.cartDao();
        adapter = new CartListAdapter(this);
        cartListView.setAdapter(adapter);
        findViewById(R.id.orderNow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.orderDao().orderCartLists(adapter.getCartList(),preferences.getInt("User_UID", 0));
                finish();
            }
        });
        loadCartData();
    }

    private void loadCartData() {
        List<CartItem> cartItemList  =  new ArrayList<>(cartDao.getCartDB(preferences.getInt("User_UID", 0)));
        adapter.setCartList(cartItemList);
        totalItems.setText(""+cartItemList.size());
        double total = 0;
        for(CartItem item:cartItemList){
            total += item.getTotalQuantity()* item.getMenuItem().getPrice();
        }
        totalAmount.setText("$ "+total);
    }

    @Override
    public void onQuantityChange(CartItem item) {
        if(cartDao != null){
            cartDao.insertCart(item);
            loadCartData();
        }
    }

    @Override
    public void onCartDelete(CartItem item) {
        if(cartDao != null){
            cartDao.deleteCart(item);
            loadCartData();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Cart");
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}