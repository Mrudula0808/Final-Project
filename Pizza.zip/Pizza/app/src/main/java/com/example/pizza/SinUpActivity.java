package com.example.pizza;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;

import com.example.pizza.database.AppDatabase;
import com.example.pizza.database.DatabaseClient;
import com.example.pizza.database.dao.UserDao;
import com.example.pizza.database.model.User;

public class SinUpActivity extends AppCompatActivity {
    private AppCompatEditText userName, userMail, userPassword, confirmPassword;
    private AppDatabase db;
    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sin_up);
        userMail = findViewById(R.id.email);
        userPassword = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirm_password);
        userName = findViewById(R.id.userName);
        db = DatabaseClient.getInstance(getApplicationContext()).getAppDb();
        userDao = db.userDao();
        findViewById(R.id.confirm_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = userName.getText().toString().trim();
                String user = userMail.getText().toString().trim();
                String password = userPassword.getText().toString().trim();
                String confirmPass = confirmPassword.getText().toString().trim();
                if (TextUtils.isEmpty(name)) {
                    userName.setError("Enter User Name");
                } else if (TextUtils.isEmpty(user)) {
                    userMail.setError("Enter User Mail");
                } else if (TextUtils.isEmpty(password)) {
                    userPassword.setError("Set Password");
                } else if (!password.equals(confirmPass)) {
                    confirmPassword.setError("Confirm Password same as password");
                } else {
                    User existing = userDao.getUserByMailId(user);
                    if (existing == null) {
                        existing = new User();
                        existing.setUserEmail(user);
                        existing.setUserPassword(password);
                        existing.setUserName(name);
                        userDao.insertUser(existing);
                        finish();
                    } else {
                        Toast.makeText(SinUpActivity.this, "User Already Existing With Mail", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}