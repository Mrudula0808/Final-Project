package com.example.pizza.database;

import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.pizza.database.dao.CartDao;
import com.example.pizza.database.dao.MenuDao;
import com.example.pizza.database.dao.OrderDao;
import com.example.pizza.database.dao.UserDao;
import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.MenuItem;
import com.example.pizza.database.model.OrderItem;
import com.example.pizza.database.model.Orders;
import com.example.pizza.database.model.User;


@Database(entities = {User.class, MenuItem.class, OrderItem.class, Orders.class, CartItem.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract OrderDao orderDao();

    public abstract CartDao cartDao();

    public abstract MenuDao menuDao();

    public abstract UserDao userDao();
}
