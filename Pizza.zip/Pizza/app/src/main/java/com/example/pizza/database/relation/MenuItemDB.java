package com.example.pizza.database.relation;

import androidx.room.Relation;

import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.MenuItem;
import com.example.pizza.database.model.OrderItem;
import com.example.pizza.database.model.Orders;

public class MenuItemDB extends MenuItem {

    @Relation(parentColumn = "id",
            entityColumn = "menuItem_id",
            entity = CartItem.class)
    private CartItem cartItem;
}
