package com.example.pizza.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pizza.R;
import com.example.pizza.database.model.CartItem;

import java.util.ArrayList;
import java.util.List;

public class CartListAdapter extends RecyclerView.Adapter<CartListAdapter.CartViewHolder> {
    private List<CartItem> cartList;
    private List<String> quantityValues = new ArrayList<>();
    private OnQuantityChangeListener changeListener;

    public interface OnQuantityChangeListener {
        void onQuantityChange(CartItem item);

        void onCartDelete(CartItem item);
    }

    public CartListAdapter(OnQuantityChangeListener changeListener) {
        this.changeListener = changeListener;
        quantityValues.clear();
        for (int i = 1; i <= 10; i++) {
            quantityValues.add(String.valueOf(i));
        }
    }

    public void setCartList(List<CartItem> cartList) {
        this.cartList = cartList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cart_list_item, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartList.get(position);
        holder.itemName.setText(item.getMenuItem().getName());
        holder.itemPrice.setText("Price: $" + item.getMenuItem().getPrice());
        holder.total.setText("Total: $" + item.getTotalQuantity() * item.getMenuItem().getPrice());
        holder.imageView.setImageResource(item.getMenuItem().getImage());
        int selectIndex = quantityValues.indexOf(String.valueOf(item.getTotalQuantity()));
        if (selectIndex != -1) {
            holder.quantitySpin.setSelection(selectIndex);
        }
    }

    @Override
    public int getItemCount() {
        return cartList == null ? 0 : cartList.size();
    }

    public List<CartItem> getCartList() {
        return cartList;
    }

    public class CartViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemPrice, total;
        ImageView imageView;
        Spinner quantitySpin;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.cart_image);
            itemName = itemView.findViewById(R.id.cart_name);
            itemPrice = itemView.findViewById(R.id.unitPrice);
            total = itemView.findViewById(R.id.cart_price);
            quantitySpin = itemView.findViewById(R.id.spinner_quantity);
            itemView.findViewById(R.id.deletedCart).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    CartItem item = cartList.get(getAdapterPosition());
                    if (item != null) {
                        if (changeListener != null) {
                            changeListener.onCartDelete(item);
                        }
                    }
                }
            });
            ArrayAdapter adapter = new ArrayAdapter(itemView.getContext(), android.R.layout.simple_list_item_1, quantityValues);
            quantitySpin.setAdapter(adapter);
            quantitySpin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    String rawQuantity = (String) adapterView.getAdapter().getItem(i);
                    int finalValue = Integer.valueOf(rawQuantity);
                    CartItem item = cartList.get(getAdapterPosition());
                    if (item != null && finalValue != item.getTotalQuantity()) {
                        item.setTotalQuantity(finalValue);
                        if (changeListener != null) {
                            changeListener.onQuantityChange(item);
                        }
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });
        }
    }
}
