package com.example.pizza.database.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.pizza.database.model.User;

@Dao
public interface UserDao {
    @Insert
    void insertUser(User user);

    @Query("Select * from user where userEmail=:userMail")
    User getUserByMailId(String userMail);

    @Query("Select * from user where userEmail=:userMail and userPassword=:password")
    User getExistingUser(String userMail, String password);
}
