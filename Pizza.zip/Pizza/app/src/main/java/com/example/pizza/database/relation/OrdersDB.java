package com.example.pizza.database.relation;

import androidx.room.Relation;

import com.example.pizza.database.model.MenuItem;
import com.example.pizza.database.model.OrderItem;
import com.example.pizza.database.model.Orders;

import java.util.List;

public class OrdersDB extends Orders {

    @Relation(entityColumn = "orderItem_id",
            parentColumn = "id",
            entity = OrderItem.class)
    private List<OrderItem> orderItems;
}
