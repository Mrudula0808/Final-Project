package com.example.pizza;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.pizza.adapters.CartListAdapter;
import com.example.pizza.adapters.OrderItemsListAdapter;
import com.example.pizza.database.AppDatabase;
import com.example.pizza.database.DatabaseClient;
import com.example.pizza.database.dao.CartDao;
import com.example.pizza.database.dao.OrderDao;
import com.example.pizza.database.model.Orders;

public class OrderDetailsActivity extends AppCompatActivity {
    private RecyclerView cartListView;
    private TextView totalItems,totalAmount;
    private AppDatabase db;
    private OrderDao orderDao;
    private OrderItemsListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_details);
        cartListView = findViewById(R.id.cart_list_handler);
        totalItems = findViewById(R.id.totalCartSize);
        totalAmount = findViewById(R.id.totalCartAmount);
        db = DatabaseClient.getInstance(getApplicationContext()).getAppDb();
        orderDao = db.orderDao();
        Intent menuIntent = getIntent();
        if(menuIntent != null && menuIntent.getExtras()!= null){
            int orderId =  menuIntent.getExtras().getInt("order_uid",-1);
            if(orderId != -1){
                loadOrderDetails(orderId);
            }
        }
    }

    private void loadOrderDetails(int orderId) {
        Orders orders = orderDao.getOrderDB(orderId);
        adapter = new OrderItemsListAdapter(orders.getOrderItems());
        cartListView.setAdapter(adapter);
        totalItems.setText(""+orders.getTotalQuantity());
        totalAmount.setText("$ "+orders.getTotalPrice());

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Order Details");
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}