package com.example.pizza.database.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.pizza.database.model.CartItem;
import com.example.pizza.database.model.MenuItem;
import com.example.pizza.database.relation.MenuItemDB;

import java.util.List;

@Dao
public interface MenuDao {
    @Query("SELECT * FROM menu")
    List<MenuItem> getAllMenuItem();

    @Query("SELECT * FROM menu")
    List<MenuItemDB> getMenuDB();

    @Query("SELECT * FROM menu where id = :menuId")
    MenuItem getMenuItemDB(int menuId);

    @Insert
    void insertMenu(MenuItem menu);

    @Insert
    void insertListMenu(List<MenuItem> menuItemList);

    @Update
    void updateMenu(MenuItem orderItem);

    @Delete
    void deleteMenu(MenuItem orderItem);

    @Query("SELECT * FROM cart where  menuItem_id= :menuId and user_uid=:user_uid")
    CartItem getCart(int menuId, int user_uid);
}
