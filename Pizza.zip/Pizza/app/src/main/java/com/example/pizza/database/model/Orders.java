package com.example.pizza.database.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.List;

@Entity(tableName = "orders", foreignKeys = {
        @ForeignKey(entity = User.class, childColumns = "user_uid", parentColumns = "id", onDelete = ForeignKey.NO_ACTION)
})
public class Orders {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "totalQuantity")
    private int totalQuantity;

    @ColumnInfo(name = "totalPrice")
    private int totalPrice;

    @ColumnInfo(name = "orderItem_id")
    private int orderItem_id;
    private int user_uid;

    @Ignore
    private List<OrderItem> orderItems;

    public Orders() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(int totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public int getOrderItem_id() {
        return orderItem_id;
    }

    public void setOrderItem_id(int orderItem_id) {
        this.orderItem_id = orderItem_id;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    public int getUser_uid() {
        return user_uid;
    }

    public void setUser_uid(int user_uid) {
        this.user_uid = user_uid;
    }
}