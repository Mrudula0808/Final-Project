package com.example.pizza.database.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "cart", foreignKeys = {

        @ForeignKey(entity = MenuItem.class, childColumns = "menuItem_id", parentColumns = "id", onDelete = ForeignKey.NO_ACTION),
        @ForeignKey(entity = User.class, childColumns = "user_uid", parentColumns = "id", onDelete = ForeignKey.NO_ACTION)
})
public class CartItem {
    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "totalQuantity")
    private int totalQuantity;

    @ColumnInfo(name = "menuItem_id")
    private int menuItem_id;

    private int user_uid;

    @Ignore
    private MenuItem menuItem;

    public CartItem() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(int totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public int getMenuItem_id() {
        return menuItem_id;
    }

    public void setMenuItem_id(int menuItem_id) {
        this.menuItem_id = menuItem_id;
    }

    public MenuItem getMenuItem() {
        return menuItem;
    }

    public void setMenuItem(MenuItem menuItem) {
        this.menuItem = menuItem;
    }

    public int getUser_uid() {
        return user_uid;
    }

    public void setUser_uid(int user_uid) {
        this.user_uid = user_uid;
    }
}